import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  bookListForm!: FormGroup;
  isSubmitted: boolean = false;
  isEdit: boolean = false;
  EditRowIndex: number = 0;
  bookList = [
      {
      bookId: "GF07",
      title: "House of Earth and Blood",
      author: "Sarah J. Maas",
      publishedDate: "2023-03-17",
      price: "100"
    },
    {
      bookId: "GF08",
      title: "Walking with Sam",
      author: "Andrew McCarthy",
      publishedDate: "2021-03-17",
      price: "200"
    }
  ]

  constructor(private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.bookListForm = this.formBuilder.group({
      bookId: ['', Validators.required],
      title: ['', Validators.required],
      author: ['', Validators.required],
      publishedDate: ['', Validators.required],
      price: ['', Validators.required],
    });
  }
  get f() { return this.bookListForm.controls; }

  addEditBook() {
    this.isSubmitted = true;
    if (this.bookListForm.valid) {
      if (this.isEdit) {
        this.bookList[this.EditRowIndex] = this.bookListForm.value;
        this.bookListForm.reset();
        this.isSubmitted = false;
        this.isEdit = false;
      }
      else {
        this.bookList.push(this.bookListForm.value);
        this.bookListForm.reset();
        this.isSubmitted = false;
      }
    }
  }

  deleteBookList(index: number) {
    this.bookList.splice(index, 1);
  }

  editBookList(data: any, index: number) {
    this.isEdit = true;
    this.EditRowIndex = index;
    this.bookListForm.patchValue({
      bookId: data.bookId,
      title: data.title,
      author: data.author,
      publishedDate: data.publishedDate,
      price: data.price
    });
  }
}
