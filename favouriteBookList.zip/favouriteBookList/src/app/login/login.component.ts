import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  isSubmitted: boolean = false;

  constructor(private router: Router, private accountService: AccountService, private formBuilder: FormBuilder) { }
  
  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }
  get f() { return this.loginForm.controls; }
  onSubmit() {
    this.isSubmitted = true;
    let user = JSON.parse(localStorage.getItem("user")!);
    if (this.loginForm.value.username != "" && user.userName != this.loginForm.value.username) {
      this.f['username'].setErrors({
        invalidUserName: true
      });
    }
    if (this.loginForm.value.password != "" && user.password != this.loginForm.value.password) {
      this.f['password'].setErrors({
        invalidPassword: true
      });
    }
    if (this.isSubmitted && this.loginForm.valid) {
      this.accountService.login(this.loginForm.value.username, this.loginForm.value.password);
      this.router.navigate(['home']);
    }
    
  }
}
