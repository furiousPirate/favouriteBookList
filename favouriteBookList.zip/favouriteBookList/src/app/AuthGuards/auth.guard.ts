import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';
@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  
    constructor(
      private router: Router,
      private accountService: AccountService
    ) {}
  public password: string = '';
  public username: string = '';
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    this.accountService.behaviorusername().subscribe((userName: string) => {
      this.username = userName;
    });
    this.accountService.behaviorPassword().subscribe((password: string) => {
      this.password = password;
    });
    let user = JSON.parse(localStorage.getItem("user")!);
    if ((this.username === user.userName && this.password === user.password) || user.isUserLoggedIn) {
      let userDetails: object = {
        userName: user.userName,
        password: user.password,
        isUserLoggedIn: true
      };
      localStorage.setItem("user", JSON.stringify(userDetails));
      return true;
    }
    this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
        return false;
    }
}
