import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'favouriteBookList';
  userDetails: object = {
    userName: "user@user.com",
    password: "8ed46d8",
    isUserLoggedIn:false
  };
  constructor() {
    if (!localStorage.getItem("user")) {
      localStorage.setItem("user", JSON.stringify(this.userDetails));
    }
    
  }
}
