import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AccountService {
  private username = new BehaviorSubject<string>('');
  private password = new BehaviorSubject<string>('');
  constructor(
  ) {  }


  login(userName: string, password: string) {
    this.username.next(userName);
    this.password.next(password);
  }
  behaviorusername(): Observable<string> {
    return this.username.asObservable()
  }
  behaviorPassword(): Observable<string> {
    return this.password.asObservable()
  }
}
